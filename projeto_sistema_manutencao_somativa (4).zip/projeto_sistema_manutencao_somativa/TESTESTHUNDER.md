Maquinas - GET
![alt text](image-2.png)

Maquinas - POST
![alt text](image-3.png)

Maquinas - PUT
![alt text](image-4.png)

Maquinas - DELETE
![alt text](image-5.png)

--------------------------------------------------------------------------------------------------------------------

Manutenções - GET
![alt text](image-6.png)

Manutenções - POST
![alt text](image-7.png)

--------------------------------------------------------------------------------------------------------------------

Falhas - GET
![alt text](image-8.png)

Falhas - POST
![alt text](image-9.png)

--------------------------------------------------------------------------------------------------------------------

técnicos - GET
![alt text](image-10.png)

técnicos - Post
![alt text](image-11.png)

técnicos - DELETE
![alt text](image-12.png)